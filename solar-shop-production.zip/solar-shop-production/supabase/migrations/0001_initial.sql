-- Solar Shop: PostgreSQL schema + fail-closed RLS + transactional business functions.
create extension if not exists pgcrypto;
create type public.app_role as enum ('admin');
create type public.sale_status as enum ('completed','cancelled');
create type public.payment_method as enum ('cash','bank_transfer','card','other');
create type public.stock_movement_type as enum ('purchase_in','sale_out','sale_return','adjustment_in','adjustment_out');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  email text not null,
  display_name text not null default '',
  role public.app_role not null default 'admin',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.suppliers (
  id uuid primary key default gen_random_uuid(), code text not null unique,
  name text not null check (length(trim(name)) between 1 and 200), phone text, address text, note text,
  created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table public.customers (
  id uuid primary key default gen_random_uuid(), code text not null unique,
  name text not null check (length(trim(name)) between 1 and 200), phone text, address text, note text,
  created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table public.products (
  id uuid primary key default gen_random_uuid(), sku text not null unique,
  name text not null check (length(trim(name)) between 1 and 200), category text not null default '', unit text not null default 'cái',
  purchase_price numeric(14,2) not null default 0 check (purchase_price >= 0), sale_price numeric(14,2) not null default 0 check (sale_price >= 0),
  stock numeric(14,3) not null default 0 check (stock >= 0), low_stock_threshold numeric(14,3) not null default 0 check (low_stock_threshold >= 0),
  supplier_id uuid references public.suppliers(id) on delete set null, note text, active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table public.sales (
  id uuid primary key default gen_random_uuid(), code text not null unique,
  sold_at timestamptz not null default now(), customer_id uuid references public.customers(id) on delete set null,
  subtotal numeric(14,2) not null check (subtotal >= 0), discount numeric(14,2) not null default 0 check (discount >= 0 and discount <= subtotal),
  total numeric(14,2) generated always as (subtotal - discount) stored,
  status public.sale_status not null default 'completed', note text,
  created_by uuid not null references auth.users(id), updated_by uuid references auth.users(id),
  cancelled_at timestamptz, cancel_reason text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.sale_items (
  id uuid primary key default gen_random_uuid(), sale_id uuid not null references public.sales(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict, product_sku text not null, product_name text not null, unit text not null,
  quantity numeric(14,3) not null check (quantity > 0), unit_price numeric(14,2) not null check (unit_price >= 0),
  unit_cost numeric(14,2) not null check (unit_cost >= 0), line_total numeric(14,2) generated always as (round(quantity * unit_price,2)) stored,
  line_cost numeric(14,2) generated always as (round(quantity * unit_cost,2)) stored
);
create index sales_sold_at_idx on public.sales(sold_at desc);
create index sales_customer_idx on public.sales(customer_id);
create index sale_items_sale_idx on public.sale_items(sale_id);
create index sale_items_product_idx on public.sale_items(product_id);
create index products_name_idx on public.products using gin (to_tsvector('simple', name));
create table public.payments (
  id uuid primary key default gen_random_uuid(), sale_id uuid not null references public.sales(id) on delete restrict,
  amount numeric(14,2) not null check (amount > 0), paid_at timestamptz not null default now(),
  method public.payment_method not null default 'cash', note text, idempotency_key text not null unique,
  created_by uuid not null references auth.users(id), created_at timestamptz not null default now()
);
create index payments_sale_idx on public.payments(sale_id);
create table public.stock_movements (
  id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete restrict,
  movement_type public.stock_movement_type not null, quantity_delta numeric(14,3) not null check (quantity_delta <> 0),
  stock_before numeric(14,3) not null check (stock_before >= 0), stock_after numeric(14,3) not null check (stock_after >= 0),
  reason text not null check (length(trim(reason)) between 1 and 500), reference_type text, reference_id uuid,
  created_by uuid not null references auth.users(id), created_at timestamptz not null default now()
);
create index stock_movements_product_idx on public.stock_movements(product_id, created_at desc);
create table public.expenses (
  id uuid primary key default gen_random_uuid(), spent_at date not null default current_date,
  category text not null check (length(trim(category)) between 1 and 100), amount numeric(14,2) not null check (amount > 0),
  note text, include_in_profit boolean not null default true, created_by uuid not null references auth.users(id), created_at timestamptz not null default now()
);
create table public.purchase_receipts (
  id uuid primary key default gen_random_uuid(), code text not null unique, supplier_id uuid references public.suppliers(id) on delete set null,
  received_at timestamptz not null default now(), subtotal numeric(14,2) not null check (subtotal >= 0), freight numeric(14,2) not null default 0 check (freight >= 0),
  total numeric(14,2) not null check (total >= 0), paid numeric(14,2) not null default 0 check (paid >= 0 and paid <= total), note text,
  status text not null default 'received' check (status in ('received','cancelled')), created_by uuid not null references auth.users(id), created_at timestamptz not null default now()
);
create table public.purchase_items (
  id uuid primary key default gen_random_uuid(), receipt_id uuid not null references public.purchase_receipts(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict, product_name text not null, quantity numeric(14,3) not null check (quantity > 0),
  unit_cost numeric(14,2) not null check (unit_cost >= 0), line_total numeric(14,2) generated always as (round(quantity * unit_cost,2)) stored
);
create table public.audit_logs (
  id bigint generated always as identity primary key, actor_id uuid references auth.users(id) on delete set null,
  action text not null, entity_type text not null, entity_id text, details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs(created_at desc);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public,auth as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.active=true)
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- All tables are private by default. No anonymous access; authenticated users still need an active admin profile.
do $$ declare t text; begin
  foreach t in array array['profiles','suppliers','customers','products','sales','sale_items','payments','stock_movements','expenses','purchase_receipts','purchase_items','audit_logs'] loop
    execute format('alter table public.%I enable row level security',t);
    execute format('create policy %I on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t||'_admin_all',t);
  end loop;
end $$;
revoke all on all tables in schema public from anon, authenticated;
grant select on public.profiles, public.suppliers, public.customers, public.products, public.sales, public.sale_items, public.payments, public.stock_movements, public.expenses, public.purchase_receipts, public.purchase_items, public.audit_logs to authenticated;
grant insert, update, delete on public.suppliers, public.customers, public.expenses to authenticated;
grant insert on public.products to authenticated;
grant update (sku,name,category,unit,purchase_price,sale_price,low_stock_threshold,supplier_id,note,active,updated_at) on public.products to authenticated;
grant usage, select on all sequences in schema public to authenticated;

create or replace function public.audit_event(p_action text,p_entity_type text,p_entity_id text,p_details jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public,auth as $$
begin
 if not public.is_admin() then raise exception 'forbidden'; end if;
 insert into public.audit_logs(actor_id,action,entity_type,entity_id,details) values(auth.uid(),p_action,p_entity_type,p_entity_id,coalesce(p_details,'{}'::jsonb));
end $$;

-- Sale and inventory mutations run in a single database transaction.
create or replace function public.create_sale(p_code text,p_customer_id uuid,p_discount numeric,p_note text,p_items jsonb,p_initial_payment numeric default 0,p_method public.payment_method default 'cash')
returns uuid language plpgsql security definer set search_path=public,auth as $$
declare v_sale_id uuid; v_subtotal numeric(14,2):=0; v_discount numeric(14,2); v_total numeric(14,2); v_item jsonb; v_product public.products%rowtype; v_qty numeric(14,3); v_price numeric(14,2); v_cost numeric(14,2); v_before numeric(14,3); v_after numeric(14,3); v_paid numeric(14,2);
begin
 if not public.is_admin() then raise exception 'forbidden'; end if;
 if p_code is null or length(trim(p_code))<3 or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'invalid_sale'; end if;
 if p_initial_payment is null or p_initial_payment<0 then raise exception 'invalid_payment'; end if;
 -- Lock product rows to prevent two simultaneous sales overselling stock.
 for v_item in select value from jsonb_array_elements(p_items) loop
   v_qty := (v_item->>'quantity')::numeric;
   if v_qty<=0 then raise exception 'invalid_quantity'; end if;
   select * into v_product from public.products where id=(v_item->>'product_id')::uuid and active=true for update;
   if not found then raise exception 'product_not_found'; end if;
   if v_product.stock<v_qty then raise exception 'insufficient_stock:%',v_product.name; end if;
   v_price := coalesce((v_item->>'unit_price')::numeric,v_product.sale_price);
   if v_price<0 then raise exception 'invalid_price'; end if;
   v_subtotal := v_subtotal + round(v_qty*v_price,2);
 end loop;
 v_discount:=coalesce(p_discount,0); v_total:=v_subtotal-v_discount;
 if v_discount<0 or v_discount>v_subtotal or p_initial_payment>v_total then raise exception 'invalid_totals'; end if;
 insert into public.sales(code,customer_id,subtotal,discount,note,created_by) values(trim(p_code),p_customer_id,v_subtotal,v_discount,p_note,auth.uid()) returning id into v_sale_id;
 for v_item in select value from jsonb_array_elements(p_items) loop
   v_qty := (v_item->>'quantity')::numeric;
   select * into v_product from public.products where id=(v_item->>'product_id')::uuid for update;
   v_price := coalesce((v_item->>'unit_price')::numeric,v_product.sale_price); v_cost:=v_product.purchase_price;
   v_before:=v_product.stock; v_after:=v_before-v_qty;
   update public.products set stock=v_after,updated_at=now() where id=v_product.id;
   insert into public.sale_items(sale_id,product_id,product_sku,product_name,unit,quantity,unit_price,unit_cost)
   values(v_sale_id,v_product.id,v_product.sku,v_product.name,v_product.unit,v_qty,v_price,v_cost);
   insert into public.stock_movements(product_id,movement_type,quantity_delta,stock_before,stock_after,reason,reference_type,reference_id,created_by)
   values(v_product.id,'sale_out',-v_qty,v_before,v_after,'Bán hàng '||trim(p_code),'sale',v_sale_id,auth.uid());
 end loop;
 if p_initial_payment>0 then
   insert into public.payments(sale_id,amount,method,note,idempotency_key,created_by)
   values(v_sale_id,p_initial_payment,coalesce(p_method,'cash'),'Thanh toán khi tạo đơn',gen_random_uuid()::text,auth.uid());
 end if;
 perform public.audit_event('sale_created','sale',v_sale_id::text,jsonb_build_object('code',p_code,'total',v_total,'initial_payment',p_initial_payment));
 return v_sale_id;
end $$;

create or replace function public.record_payment(p_sale_id uuid,p_amount numeric,p_method public.payment_method,p_paid_at timestamptz,p_note text,p_idempotency_key text)
returns uuid language plpgsql security definer set search_path=public,auth as $$
declare v_sale public.sales%rowtype; v_total numeric(14,2); v_paid numeric(14,2); v_id uuid; v_existing public.payments%rowtype;
begin
 if not public.is_admin() then raise exception 'forbidden'; end if;
 if p_amount is null or p_amount<=0 or p_idempotency_key is null or length(trim(p_idempotency_key))<8 then raise exception 'invalid_payment'; end if;
 select * into v_existing from public.payments where idempotency_key=p_idempotency_key; if found then if v_existing.sale_id<>p_sale_id or v_existing.amount<>p_amount then raise exception 'idempotency_key_conflict'; end if; return v_existing.id; end if;
 select * into v_sale from public.sales where id=p_sale_id for update;
 if not found or v_sale.status<>'completed' then raise exception 'sale_unavailable'; end if;
 select coalesce(sum(amount),0) into v_paid from public.payments where sale_id=p_sale_id;
 v_total:=v_sale.total;
 if p_amount>v_total-v_paid then raise exception 'payment_exceeds_debt'; end if;
 insert into public.payments(sale_id,amount,method,paid_at,note,idempotency_key,created_by)
 values(p_sale_id,p_amount,coalesce(p_method,'cash'),coalesce(p_paid_at,now()),p_note,p_idempotency_key,auth.uid()) returning id into v_id;
 perform public.audit_event('payment_recorded','sale',p_sale_id::text,jsonb_build_object('amount',p_amount,'payment_id',v_id)); return v_id;
end $$;

create or replace function public.cancel_sale(p_sale_id uuid,p_reason text)
returns void language plpgsql security definer set search_path=public,auth as $$
declare v_sale public.sales%rowtype; v_item record; v_before numeric(14,3); v_after numeric(14,3);
begin
 if not public.is_admin() then raise exception 'forbidden'; end if;
 if length(trim(coalesce(p_reason,'')))<3 then raise exception 'cancel_reason_required'; end if;
 select * into v_sale from public.sales where id=p_sale_id for update;
 if not found then raise exception 'sale_not_found'; end if;
 if v_sale.status='cancelled' then return; end if;
 -- No silent deletion of money movement. Refund/reversal must be recorded separately before cancelling a paid sale.
 if exists(select 1 from public.payments where sale_id=p_sale_id) then raise exception 'refund_required_before_cancel'; end if;
 for v_item in select * from public.sale_items where sale_id=p_sale_id loop
   select stock into v_before from public.products where id=v_item.product_id for update;
   v_after:=v_before+v_item.quantity;
   update public.products set stock=v_after,updated_at=now() where id=v_item.product_id;
   insert into public.stock_movements(product_id,movement_type,quantity_delta,stock_before,stock_after,reason,reference_type,reference_id,created_by)
   values(v_item.product_id,'sale_return',v_item.quantity,v_before,v_after,'Hoàn kho do hủy đơn '||v_sale.code||': '||trim(p_reason),'sale',p_sale_id,auth.uid());
 end loop;
 update public.sales set status='cancelled',cancelled_at=now(),cancel_reason=trim(p_reason),updated_by=auth.uid(),updated_at=now() where id=p_sale_id;
 perform public.audit_event('sale_cancelled','sale',p_sale_id::text,jsonb_build_object('reason',p_reason));
end $$;

create or replace function public.adjust_stock(p_product_id uuid,p_delta numeric,p_reason text)
returns void language plpgsql security definer set search_path=public,auth as $$
declare v_product public.products%rowtype; v_after numeric(14,3); v_type public.stock_movement_type;
begin
 if not public.is_admin() then raise exception 'forbidden'; end if;
 if p_delta=0 or length(trim(coalesce(p_reason,'')))<3 then raise exception 'invalid_adjustment'; end if;
 select * into v_product from public.products where id=p_product_id and active=true for update;
 if not found then raise exception 'product_not_found'; end if;
 v_after:=v_product.stock+p_delta; if v_after<0 then raise exception 'negative_stock_forbidden'; end if;
 v_type:=case when p_delta>0 then 'adjustment_in'::public.stock_movement_type else 'adjustment_out'::public.stock_movement_type end;
 update public.products set stock=v_after,updated_at=now() where id=p_product_id;
 insert into public.stock_movements(product_id,movement_type,quantity_delta,stock_before,stock_after,reason,created_by)
 values(p_product_id,v_type,p_delta,v_product.stock,v_after,trim(p_reason),auth.uid());
 perform public.audit_event('stock_adjusted','product',p_product_id::text,jsonb_build_object('delta',p_delta,'reason',p_reason,'before',v_product.stock,'after',v_after));
end $$;


create or replace function public.receive_purchase(p_code text,p_supplier_id uuid,p_freight numeric,p_paid numeric,p_note text,p_items jsonb)
returns uuid language plpgsql security definer set search_path=public,auth as $$
declare v_id uuid; v_item jsonb; v_product public.products%rowtype; v_qty numeric(14,3); v_cost numeric(14,2); v_subtotal numeric(14,2):=0; v_total numeric(14,2); v_before numeric(14,3); v_after numeric(14,3);
begin
 if not public.is_admin() then raise exception 'forbidden'; end if;
 if p_code is null or length(trim(p_code))<3 or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'invalid_purchase'; end if;
 if coalesce(p_freight,0)<0 or coalesce(p_paid,0)<0 then raise exception 'invalid_amount'; end if;
 for v_item in select value from jsonb_array_elements(p_items) loop
   v_qty:=(v_item->>'quantity')::numeric; v_cost:=(v_item->>'unit_cost')::numeric;
   if v_qty<=0 or v_cost<0 then raise exception 'invalid_item'; end if;
   select * into v_product from public.products where id=(v_item->>'product_id')::uuid and active=true for update;
   if not found then raise exception 'product_not_found'; end if;
   v_subtotal:=v_subtotal+round(v_qty*v_cost,2);
 end loop;
 v_total:=v_subtotal+coalesce(p_freight,0); if coalesce(p_paid,0)>v_total then raise exception 'paid_exceeds_total'; end if;
 insert into public.purchase_receipts(code,supplier_id,subtotal,freight,total,paid,note,created_by) values(trim(p_code),p_supplier_id,v_subtotal,coalesce(p_freight,0),v_total,coalesce(p_paid,0),p_note,auth.uid()) returning id into v_id;
 for v_item in select value from jsonb_array_elements(p_items) loop
   v_qty:=(v_item->>'quantity')::numeric; v_cost:=(v_item->>'unit_cost')::numeric;
   select * into v_product from public.products where id=(v_item->>'product_id')::uuid for update;
   v_before:=v_product.stock; v_after:=v_before+v_qty;
   update public.products set stock=v_after,purchase_price=v_cost,updated_at=now() where id=v_product.id;
   insert into public.purchase_items(receipt_id,product_id,product_name,quantity,unit_cost) values(v_id,v_product.id,v_product.name,v_qty,v_cost);
   insert into public.stock_movements(product_id,movement_type,quantity_delta,stock_before,stock_after,reason,reference_type,reference_id,created_by)
   values(v_product.id,'purchase_in',v_qty,v_before,v_after,'Nhập hàng '||trim(p_code),'purchase',v_id,auth.uid());
 end loop;
 perform public.audit_event('purchase_received','purchase',v_id::text,jsonb_build_object('code',p_code,'total',v_total,'paid',p_paid)); return v_id;
end $$;

revoke all on function public.receive_purchase(text,uuid,numeric,numeric,text,jsonb) from public, anon;
grant execute on function public.receive_purchase(text,uuid,numeric,numeric,text,jsonb) to authenticated;
revoke all on function public.create_sale(text,uuid,numeric,text,jsonb,numeric,public.payment_method) from public, anon;
revoke all on function public.record_payment(uuid,numeric,public.payment_method,timestamptz,text,text) from public, anon;
revoke all on function public.cancel_sale(uuid,text) from public, anon;
revoke all on function public.adjust_stock(uuid,numeric,text) from public, anon;
grant execute on function public.create_sale(text,uuid,numeric,text,jsonb,numeric,public.payment_method) to authenticated;
grant execute on function public.record_payment(uuid,numeric,public.payment_method,timestamptz,text,text) to authenticated;
grant execute on function public.cancel_sale(uuid,text) to authenticated;
grant execute on function public.adjust_stock(uuid,numeric,text) to authenticated;


-- Audit changes made through ordinary admin CRUD as well as RPCs.
create or replace function public.audit_row_change() returns trigger
language plpgsql security definer set search_path=public,auth as $$
declare v_id text; v_details jsonb;
begin
 if tg_op='DELETE' then v_id:=coalesce(to_jsonb(old)->>'id',to_jsonb(old)->>'sku',to_jsonb(old)->>'code'); v_details:=jsonb_build_object('before',to_jsonb(old));
 elsif tg_op='UPDATE' then v_id:=coalesce(to_jsonb(new)->>'id',to_jsonb(new)->>'sku',to_jsonb(new)->>'code'); v_details:=jsonb_build_object('before',to_jsonb(old),'after',to_jsonb(new));
 else v_id:=coalesce(to_jsonb(new)->>'id',to_jsonb(new)->>'sku',to_jsonb(new)->>'code'); v_details:=jsonb_build_object('after',to_jsonb(new)); end if;
 insert into public.audit_logs(actor_id,action,entity_type,entity_id,details) values(auth.uid(),lower(tg_op),tg_table_name,v_id,v_details);
 return case when tg_op='DELETE' then old else new end;
end $$;
create trigger audit_products after insert or update or delete on public.products for each row execute function public.audit_row_change();
create trigger audit_customers after insert or update or delete on public.customers for each row execute function public.audit_row_change();
create trigger audit_suppliers after insert or update or delete on public.suppliers for each row execute function public.audit_row_change();
create trigger audit_expenses after insert or update or delete on public.expenses for each row execute function public.audit_row_change();

-- Profiles are provisioned manually by an existing project owner using SQL Editor after verifying auth.users.id.
-- Never allow a public signup or trigger to grant admin automatically.
