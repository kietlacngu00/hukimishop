import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Quản lý bán hàng | Thiết bị điện & năng lượng mặt trời', description: 'Hệ thống quản lý bán hàng nội bộ' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="vi"><body>{children}</body></html>; }
