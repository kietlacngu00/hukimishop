import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
export async function createClient() {
  const cookieStore = await cookies();
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error('Thiếu cấu hình Supabase. Hãy thiết lập biến môi trường theo .env.example.');
  return createServerClient(url, key, { cookies: {
    getAll() { return cookieStore.getAll(); },
    setAll(items) { try { items.forEach(({ name, value, options }) => cookieStore.set(name, value, options)); } catch { /* refreshed by middleware */ } },
  }});
}
