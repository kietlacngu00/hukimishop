import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect('/login');
  const { data: profile, error: profileError } = await supabase.from('profiles').select('role, display_name, active').eq('id', user.id).maybeSingle();
  if (profileError || !profile || profile.role !== 'admin' || !profile.active) redirect('/login?error=unauthorized');
  return { supabase, user, profile };
}
