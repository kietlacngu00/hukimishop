import { describe, expect, it } from 'vitest';
function calculate(subtotal:number,discount:number,cost:number,expenses:number){const revenue=subtotal-discount;const gross=revenue-cost;return {revenue,gross,profit:gross-expenses};}
describe('business report calculations',()=>{it('subtracts discount before cost and operating expenses',()=>{expect(calculate(1000000,50000,600000,100000)).toEqual({revenue:950000,gross:350000,profit:250000});});it('allows zero margin without negative arithmetic surprises',()=>{expect(calculate(100,0,100,0)).toEqual({revenue:100,gross:0,profit:0});});});
