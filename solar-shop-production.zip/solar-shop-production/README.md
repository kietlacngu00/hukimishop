# Solar Shop Management — source project

A new Next.js + TypeScript + Supabase PostgreSQL application for a Vietnamese solar/electrical equipment shop. This repository is a source-code deliverable, **not yet deployed or verified against a real Supabase project**. No production data, admin user, cloud project, or secret is included.

## Implemented in this source tree

- Server-rendered app with Supabase Auth and an admin-profile check on protected pages.
- PostgreSQL schema, foreign keys, constraints, indexes, RLS policies, audit log, and transactional RPCs for sale creation, payment recording, cancellation (only before payments), stock adjustment, and receiving a purchase.
- Products, customers, suppliers, sales/debts, purchase receipts, expenses, dashboard, reports, audit log, and JSON export routes.
- Sale items snapshot the SKU/name/unit, sale price, and purchase cost at sale time. Inventory decrement and sale rows happen in one PostgreSQL transaction; product rows are locked to avoid concurrent overselling.
- Payment RPC accepts an idempotency key. Stock movements and key business events are recorded.
- Mobile responsive layout and Vietnamese VND/date formatting.

## Important current limitations — do not skip

This is an initial functional baseline, not a completed production acceptance. Product/customer/supplier forms currently create records but do not yet include full edit/archive/search UX. The quick sale and purchase forms accept one product line each. Purchase freight is stored separately and is not allocated into unit cost. Cancellation is intentionally blocked after any payment; a refund/reversal workflow must be implemented before cancelling paid sales. Full edit-sale/reversal workflows, purchase payment ledger, customer statement UI, date-range report filters, CSV export, restore UI, rate limiting, automated cloud backup configuration, and full integration/security tests still need implementation and validation. A password-reset request and update page are included but must be tested with configured Supabase email delivery and redirect URLs. The JSON export caps each table at 10,000 rows and should not be treated as a complete backup for larger datasets. The `profiles.role` enum currently supports only `admin` (no staff roles).

Do not use this version as the sole ledger for a live shop until those limitations are addressed, SQL has been applied and tested, and the production checklist passes.

## Requirements

- Node.js 20.9+ (recommended) and npm.
- A Supabase project.
- A hosting project such as Vercel for HTTPS deployment.

## 1. Configure Supabase

1. Create a new Supabase project and keep its database password private.
2. In Supabase SQL Editor, run `supabase/migrations/0001_initial.sql` against the empty project. Review the SQL before applying it.
3. In Authentication settings, disable public signups. Configure email delivery and an allowed redirect URL for your eventual HTTPS domain.
4. In Authentication > Users, create the first user using an invitation or the dashboard's secure user-creation flow. Require a strong unique password and email verification where available.
5. Copy that user's UUID and verified email. In SQL Editor, run this statement after replacing both placeholders with the exact values (do not add a password here):

```sql
insert into public.profiles (id, email, display_name, role, active)
values ('AUTH_USER_UUID_HERE', 'ADMIN_EMAIL_HERE', 'Quản trị viên', 'admin', true);
```

The profile is the explicit allow-list for administrator access. Never expose the Supabase `service_role` key to the browser or commit it to Git.

6. Under Project Settings > API, copy the project URL and the publishable/anon key. The frontend needs only these two public configuration values; RLS is the security boundary.

## 2. Run locally

```bash
cp .env.example .env.local
# Fill in NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm install
npm run typecheck
npm run lint
npm test
npm run build
npm run dev
```

Open `http://localhost:3000`. Use the first admin's email and password. Never paste keys or passwords into a public issue or commit `.env.local`.

## 3. Deploy to HTTPS hosting

1. Create a private Git repository and push this source (ensure `.env.local` is ignored).
2. Import it into Vercel or another Next.js host.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` as project environment variables for Preview/Production.
4. Deploy. Configure the final HTTPS domain in Supabase Auth URL Configuration and redirect URLs.
5. Test login, denied anonymous access, sale/stock/payment workflows, export, and mobile layout. `/api/health` only confirms env variables exist; it deliberately does **not** claim the database is healthy.
6. Configure Supabase database backups/PITR according to the plan and verify a restore into a separate project. This source does not configure automatic backups for you.

## 4. Data correctness notes

- Sale creation and inventory movements run inside a database transaction via `create_sale`.
- The `record_payment` RPC rejects payments over the remaining debt and de-duplicates retries by `idempotency_key`.
- Cancellation is soft-status-based, never a hard delete, and restores stock once. Paid sales require a separately recorded refund/reversal flow first.
- Gross profit = net sale total less item cost snapshots. Estimated profit = gross profit less expenses flagged for profit reporting. Supplier purchases are not also treated as operating expenses.
- Management reports are not official accounting/tax statements.

## 5. Before real production use

- Complete the limitations above, especially restore and refund workflows.
- Add integration tests against a disposable Supabase project, including two concurrent sales against the same stock, retries, RLS denial, and rollback cases.
- Review SQL policies with an independent security review. Consider adding rate limiting, CSP/security headers, alerting, and an external error monitor.
- Verify export completeness and implement paginated streaming for tables over 10,000 rows.
- Establish an off-site backup retention policy and perform documented restore drills.
